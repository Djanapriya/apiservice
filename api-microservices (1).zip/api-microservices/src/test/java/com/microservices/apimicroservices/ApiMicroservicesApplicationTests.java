package com.microservices.apimicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
